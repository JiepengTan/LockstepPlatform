using UnityEngine;
using NaughtyAttributes;
using System.Collections.Generic;

[CreateAssetMenu(fileName = "NaughtyScriptableObject", menuName = "NaughtyAttributes/NaughtyScriptableObject")]
public class NaughtyScriptableObject : ScriptableObject
{
}
