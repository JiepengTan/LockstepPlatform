﻿using System;

namespace NaughtyAttributes
{
    public abstract class DrawerAttribute : NaughtyAttribute
    {
    }
}